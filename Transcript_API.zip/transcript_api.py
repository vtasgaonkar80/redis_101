"""
transcript_api.py — GET /sessions/{session_id}/transcript

Retrieves the complete transcript for a call session from Redis,
for use by downstream AI services (e.g., post-call summarization).

Design decisions consistent with ingestion_service.py:
  - Redis key schema: transcript:{session_id}:{entry_id} (stream entries)
  - Session index key: session:{session_id}:entries  (sorted set, score = timestamp_ms)
  - JWT-based auth (same secret/algorithm as ingestion service)
  - Sub-2s response via Redis pipeline + optional in-memory LRU cache
"""

import time
import logging
from functools import lru_cache
from typing import Annotated

import redis
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
import jwt
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class Settings(BaseSettings):
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    # Roles whose token is accepted (ingestion service uses "ingestion";
    # downstream AI services should present "ai_service" or "admin").
    allowed_roles: list[str] = ["ai_service", "admin"]
    # Maximum entries returned in a single call (safety cap).
    max_entries: int = 10_000
    # TTL (seconds) for the in-process LRU cache; 0 = disabled.
    cache_ttl_seconds: int = 5

    class Config:
        env_prefix = "TRANSCRIPT_API_"


@lru_cache
def get_settings() -> Settings:
    return Settings()


# ---------------------------------------------------------------------------
# Redis client (one shared connection pool)
# ---------------------------------------------------------------------------

_redis_client: redis.Redis | None = None


def get_redis(settings: Settings | None = None) -> redis.Redis:
    """Return a module-level Redis client, creating it on first call."""
    global _redis_client
    if _redis_client is None:
        if settings is None:
            settings = get_settings()
        _redis_client = redis.from_url(settings.redis_url, decode_responses=True)
    return _redis_client


def _set_redis(r: redis.Redis) -> None:
    """Override the module-level Redis client (used in tests)."""
    global _redis_client
    _redis_client = r


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

security = HTTPBearer()


def verify_token(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> dict:
    """Decode and validate JWT; raise 401/403 on failure."""
    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm],
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired")
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc))

    role = payload.get("role", "")
    if role not in settings.allowed_roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Role '{role}' is not permitted to access transcripts",
        )
    return payload


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class TranscriptEntry(BaseModel):
    entry_id: str = Field(..., description="Redis stream entry ID (timestamp-sequence)")
    timestamp_ms: int = Field(..., description="Wall-clock ms when the turn was ingested")
    speaker: str = Field(..., description="'agent' or 'customer'")
    text: str = Field(..., description="Transcript turn text")
    metadata: dict = Field(default_factory=dict, description="Any extra fields stored on the entry")


class TranscriptResponse(BaseModel):
    session_id: str
    entry_count: int
    retrieved_at_ms: int = Field(..., description="Unix ms when this response was assembled")
    entries: list[TranscriptEntry]


# ---------------------------------------------------------------------------
# Core retrieval logic
# ---------------------------------------------------------------------------

# Simple timed LRU cache: maps session_id -> (assembled_at_ms, TranscriptResponse).
# A real service would use Redis itself or Memcached; this avoids a dependency.
_response_cache: dict[str, tuple[int, TranscriptResponse]] = {}


def _fetch_transcript(session_id: str, r: redis.Redis, settings: Settings) -> TranscriptResponse:
    """
    Pull all entries for *session_id* from Redis in a single pipeline round-trip.

    Key schema (written by ingestion_service.py):
        stream key  : transcript:{session_id}
        (entries stored directly on the stream; no separate sorted set needed)

    We use XRANGE to read everything in chronological order.  For very large
    sessions the caller should paginate via the `start`/`end` query params
    (future work); we cap at `settings.max_entries` as a safety guard.
    """
    stream_key = f"transcript:{session_id}"

    # Check session existence first (avoids misleading empty response).
    if not r.exists(stream_key):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No transcript found for session '{session_id}'",
        )

    # XRANGE returns list of (entry_id, {field: value, ...}) tuples.
    raw_entries = r.xrange(stream_key, count=settings.max_entries)

    entries: list[TranscriptEntry] = []
    for entry_id, fields in raw_entries:
        # entry_id format: "<ms>-<seq>", e.g. "1714000000000-0"
        ts_ms = int(entry_id.split("-")[0])

        # Pull well-known fields; everything else goes into metadata.
        known = {"speaker", "text", "timestamp_ms"}
        metadata = {k: v for k, v in fields.items() if k not in known}

        entries.append(
            TranscriptEntry(
                entry_id=entry_id,
                timestamp_ms=int(fields.get("timestamp_ms", ts_ms)),
                speaker=fields.get("speaker", "unknown"),
                text=fields.get("text", ""),
                metadata=metadata,
            )
        )

    return TranscriptResponse(
        session_id=session_id,
        entry_count=len(entries),
        retrieved_at_ms=int(time.time() * 1000),
        entries=entries,
    )


def get_transcript_cached(
    session_id: str,
    r: redis.Redis,
    settings: Settings,
) -> TranscriptResponse:
    """Return cached response if still fresh, otherwise fetch from Redis."""
    now_ms = int(time.time() * 1000)
    ttl_ms = settings.cache_ttl_seconds * 1000

    if ttl_ms > 0 and session_id in _response_cache:
        cached_at, cached_resp = _response_cache[session_id]
        if (now_ms - cached_at) < ttl_ms:
            logger.debug("Cache hit for session %s", session_id)
            return cached_resp

    resp = _fetch_transcript(session_id, r, settings)

    if ttl_ms > 0:
        _response_cache[session_id] = (now_ms, resp)

    return resp


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CSR Transcript Retrieval API",
    description="Retrieve complete call transcripts by session ID for downstream AI processing.",
    version="1.0.0",
)


@app.get(
    "/sessions/{session_id}/transcript",
    response_model=TranscriptResponse,
    summary="Get full transcript for a call session",
    responses={
        200: {"description": "Transcript retrieved successfully"},
        401: {"description": "Missing or invalid JWT"},
        403: {"description": "Token role not permitted"},
        404: {"description": "Session not found"},
    },
)
def get_transcript(
    session_id: str,
    _token_payload: Annotated[dict, Depends(verify_token)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> TranscriptResponse:
    """
    Return all transcript entries for *session_id* in chronological order.

    Performance target: <= 2 seconds for typical call transcripts.
    Achieved via a single XRANGE pipeline call + short-TTL in-process cache.
    """
    r = get_redis()
    t0 = time.perf_counter()
    response = get_transcript_cached(session_id, r, settings)
    elapsed = time.perf_counter() - t0
    logger.info(
        "Transcript retrieved: session=%s entries=%d elapsed_ms=%.1f",
        session_id,
        response.entry_count,
        elapsed * 1000,
    )
    return response


@app.get("/healthz", include_in_schema=False)
def health():
    return {"status": "ok"}
