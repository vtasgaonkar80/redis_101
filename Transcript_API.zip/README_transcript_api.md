# Transcript Retrieval API

GET endpoint for downstream AI services to fetch complete call transcripts by session ID.

## Overview

This service is the read-side complement to `ingestion_service.py`. It reads from the same Redis stream keys written by the ingestion service and exposes a single authenticated REST endpoint.

## Endpoint

```
GET /sessions/{session_id}/transcript
Authorization: Bearer <JWT>
```

### Response

```json
{
  "session_id": "session-abc-123",
  "entry_count": 4,
  "retrieved_at_ms": 1714000020000,
  "entries": [
    {
      "entry_id": "1714000001000-0",
      "timestamp_ms": 1714000001000,
      "speaker": "agent",
      "text": "Hello, how can I help?",
      "metadata": {}
    },
    ...
  ]
}
```

### Status codes

| Code | Meaning |
|------|---------|
| 200  | Transcript returned |
| 401  | Invalid or expired JWT |
| 403  | Missing token or role not permitted |
| 404  | No transcript found for this session ID |

## Auth

JWT signed with the same secret as the ingestion service (`TRANSCRIPT_API_JWT_SECRET`). The token payload must include `"role": "ai_service"` or `"role": "admin"`. The ingestion role is explicitly rejected.

## Redis key schema

Consistent with `ingestion_service.py`:

```
transcript:{session_id}   →  Redis Stream (XRANGE for reads, XADD for writes)
```

## Performance

- Single `XRANGE` call — one Redis round-trip for the entire transcript.
- Optional short-TTL in-process LRU cache (`TRANSCRIPT_API_CACHE_TTL_SECONDS`, default 5s).
- Measured under 2s for transcripts up to 1 000 turns in load tests.

## Configuration

All settings via environment variables (prefix `TRANSCRIPT_API_`):

| Variable | Default | Description |
|----------|---------|-------------|
| `TRANSCRIPT_API_REDIS_URL` | `redis://localhost:6379/0` | Redis connection URL |
| `TRANSCRIPT_API_JWT_SECRET` | `change-me-in-production` | Shared JWT signing secret |
| `TRANSCRIPT_API_JWT_ALGORITHM` | `HS256` | JWT algorithm |
| `TRANSCRIPT_API_ALLOWED_ROLES` | `["ai_service","admin"]` | Roles permitted to read |
| `TRANSCRIPT_API_MAX_ENTRIES` | `10000` | Safety cap on entries returned |
| `TRANSCRIPT_API_CACHE_TTL_SECONDS` | `5` | In-process cache TTL (0 = off) |

## Running

```bash
pip install fastapi uvicorn redis pyjwt pydantic-settings
uvicorn transcript_api:app --host 0.0.0.0 --port 8001
```

## Tests

```bash
pip install pytest fakeredis httpx
pytest test_transcript_api.py -v
```

Tests map 1:1 to acceptance criteria:

| Test class | AC |
|------------|----|
| `TestAC1FullTranscriptBySessionId` | AC1 — Returns full transcript by session ID |
| `TestAC2EntriesWithMetadata` | AC2 — All entries with metadata included |
| `TestAC3AuthAndAuthz` | AC3 — Authentication and authorization |
| `TestAC4ResponseTimeUnder2s` | AC4 — Response time ≤ 2s |
