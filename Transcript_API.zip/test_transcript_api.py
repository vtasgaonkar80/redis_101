"""
test_transcript_api.py

Acceptance criteria (from ticket):
  AC1 — API endpoint returns full transcript by session ID
  AC2 — Response includes all transcript entries with metadata
  AC3 — API is secured with authentication and authorization
  AC4 — API response time is <= 2 seconds for typical call transcripts

Mirrors the fakeredis + pytest patterns from test_ingestion_service.py.
"""

import time
import json
import pytest
import fakeredis
import jwt
from fastapi.testclient import TestClient
from unittest.mock import patch

from transcript_api import app, get_redis, get_settings, Settings, _response_cache, _set_redis

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TEST_SECRET = "test-secret"
TEST_SESSION = "session-abc-123"

SAMPLE_ENTRIES = [
    {"speaker": "agent",    "text": "Hello, how can I help?",       "timestamp_ms": "1714000001000"},
    {"speaker": "customer", "text": "My order hasn't arrived.",      "timestamp_ms": "1714000005000"},
    {"speaker": "agent",    "text": "Let me look that up for you.",  "timestamp_ms": "1714000010000"},
    {"speaker": "customer", "text": "Order number is 98765.",        "timestamp_ms": "1714000015000", "order_id": "98765"},
]


@pytest.fixture
def settings_override():
    return Settings(
        redis_url="redis://localhost",  # won't be used — we patch get_redis
        jwt_secret=TEST_SECRET,
        jwt_algorithm="HS256",
        allowed_roles=["ai_service", "admin"],
        cache_ttl_seconds=0,  # disable cache so each test sees fresh state
    )


@pytest.fixture
def fake_redis(settings_override):
    """Populate fakeredis with sample transcript entries."""
    r = fakeredis.FakeRedis(decode_responses=True)
    stream_key = f"transcript:{TEST_SESSION}"
    for entry in SAMPLE_ENTRIES:
        r.xadd(stream_key, entry)
    return r


@pytest.fixture
def client(settings_override, fake_redis):
    """FastAPI test client with Redis and settings patched."""
    _response_cache.clear()
    _set_redis(fake_redis)

    app.dependency_overrides[get_settings] = lambda: settings_override

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()
    _set_redis(None)


def make_token(role: str = "ai_service", secret: str = TEST_SECRET, expired: bool = False) -> str:
    payload = {"sub": "svc-summarizer", "role": role}
    if expired:
        payload["exp"] = int(time.time()) - 60
    return jwt.encode(payload, secret, algorithm="HS256")


def auth(role: str = "ai_service") -> dict:
    return {"Authorization": f"Bearer {make_token(role)}"}


# ---------------------------------------------------------------------------
# AC1 — API endpoint returns full transcript by session ID
# ---------------------------------------------------------------------------

class TestAC1FullTranscriptBySessionId:
    def test_returns_200_for_known_session(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        assert resp.status_code == 200

    def test_response_contains_correct_session_id(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        assert resp.json()["session_id"] == TEST_SESSION

    def test_returns_404_for_unknown_session(self, client):
        resp = client.get("/sessions/nonexistent-xyz/transcript", headers=auth())
        assert resp.status_code == 404

    def test_entry_count_matches_ingested_turns(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        data = resp.json()
        assert data["entry_count"] == len(SAMPLE_ENTRIES)
        assert len(data["entries"]) == len(SAMPLE_ENTRIES)

    def test_entries_in_chronological_order(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        ts_list = [e["timestamp_ms"] for e in resp.json()["entries"]]
        assert ts_list == sorted(ts_list)


# ---------------------------------------------------------------------------
# AC2 — Response includes all transcript entries with metadata
# ---------------------------------------------------------------------------

class TestAC2EntriesWithMetadata:
    def test_all_required_fields_present(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        for entry in resp.json()["entries"]:
            assert "entry_id" in entry
            assert "timestamp_ms" in entry
            assert "speaker" in entry
            assert "text" in entry
            assert "metadata" in entry

    def test_speaker_values_are_correct(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        speakers = [e["speaker"] for e in resp.json()["entries"]]
        assert speakers == ["agent", "customer", "agent", "customer"]

    def test_text_content_is_correct(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        texts = [e["text"] for e in resp.json()["entries"]]
        expected = [e["text"] for e in SAMPLE_ENTRIES]
        assert texts == expected

    def test_extra_fields_surfaced_as_metadata(self, client):
        """Entry 4 has an extra 'order_id' field — must appear in metadata."""
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        last_entry = resp.json()["entries"][-1]
        assert last_entry["metadata"].get("order_id") == "98765"

    def test_entries_without_extra_fields_have_empty_metadata(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        # First entry has no extra fields
        assert resp.json()["entries"][0]["metadata"] == {}

    def test_response_includes_retrieved_at_ms(self, client):
        before = int(time.time() * 1000)
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        after = int(time.time() * 1000)
        ts = resp.json()["retrieved_at_ms"]
        assert before <= ts <= after


# ---------------------------------------------------------------------------
# AC3 — API is secured with authentication and authorization
# ---------------------------------------------------------------------------

class TestAC3AuthAndAuthz:
    def test_missing_token_returns_401(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript")
        assert resp.status_code == 401

    def test_invalid_token_returns_401(self, client):
        resp = client.get(
            f"/sessions/{TEST_SESSION}/transcript",
            headers={"Authorization": "Bearer not-a-real-token"},
        )
        assert resp.status_code == 401

    def test_expired_token_returns_401(self, client):
        token = make_token(expired=True)
        resp = client.get(
            f"/sessions/{TEST_SESSION}/transcript",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 401

    def test_wrong_secret_returns_401(self, client):
        token = make_token(secret="wrong-secret")
        resp = client.get(
            f"/sessions/{TEST_SESSION}/transcript",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 401

    def test_disallowed_role_returns_403(self, client):
        resp = client.get(
            f"/sessions/{TEST_SESSION}/transcript",
            headers=auth(role="ingestion"),  # ingestion role cannot read transcripts
        )
        assert resp.status_code == 403

    def test_admin_role_is_allowed(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth(role="admin"))
        assert resp.status_code == 200

    def test_ai_service_role_is_allowed(self, client):
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth(role="ai_service"))
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# AC4 — API response time is <= 2 seconds for typical call transcripts
# ---------------------------------------------------------------------------

class TestAC4ResponseTimeUnder2s:
    def test_response_time_for_small_transcript(self, client):
        t0 = time.perf_counter()
        resp = client.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
        elapsed = time.perf_counter() - t0
        assert resp.status_code == 200
        assert elapsed < 2.0, f"Response took {elapsed:.3f}s — exceeded 2s SLA"

    def test_response_time_for_large_transcript(self, settings_override, fake_redis):
        """Seed 1 000 turns and confirm we stay under the 2s SLA."""
        _response_cache.clear()
        large_session = "session-large-load"
        stream_key = f"transcript:{large_session}"
        pipe = fake_redis.pipeline()
        for i in range(1000):
            pipe.xadd(stream_key, {
                "speaker": "agent" if i % 2 == 0 else "customer",
                "text": f"Turn {i}: " + ("x" * 80),
                "timestamp_ms": str(1714000000000 + i * 3000),
            })
        pipe.execute()

        app.dependency_overrides[get_settings] = lambda: settings_override
        _set_redis(fake_redis)

        with TestClient(app) as c:
            t0 = time.perf_counter()
            resp = c.get(f"/sessions/{large_session}/transcript", headers=auth())
            elapsed = time.perf_counter() - t0

        app.dependency_overrides.clear()
        _set_redis(None)

        assert resp.status_code == 200
        assert resp.json()["entry_count"] == 1000
        assert elapsed < 2.0, f"Large transcript took {elapsed:.3f}s — exceeded 2s SLA"

    def test_cache_hit_is_faster_than_uncached(self, settings_override, fake_redis):
        """With cache enabled, second call should be measurably faster."""
        cached_settings = Settings(
            redis_url="redis://localhost",
            jwt_secret=TEST_SECRET,
            cache_ttl_seconds=5,  # enable cache
        )
        _response_cache.clear()
        app.dependency_overrides[get_settings] = lambda: cached_settings
        _set_redis(fake_redis)

        with TestClient(app) as c:
            t0 = time.perf_counter()
            c.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
            cold = time.perf_counter() - t0

            t1 = time.perf_counter()
            c.get(f"/sessions/{TEST_SESSION}/transcript", headers=auth())
            warm = time.perf_counter() - t1

        app.dependency_overrides.clear()
        _set_redis(None)

        assert warm < cold, "Cache hit should be faster than cold fetch"
        assert warm < 2.0
