"""
redis_setup.py — Provision the `transcripts` stream and consumer group.

Usage:
    python redis_setup.py                   # connect via env / defaults
    python redis_setup.py --reset           # drop & recreate stream + group

Environment variables:
    REDIS_URL   redis://localhost:6379  (default)
"""

import argparse
import logging
import os
import sys

import redis

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
STREAM_KEY: str = "transcripts"
CONSUMER_GROUP: str = "transcript-ingestion-group"

log = logging.getLogger("redis_setup")
logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_client() -> redis.Redis:
    client = redis.from_url(REDIS_URL, decode_responses=True)
    client.ping()  # fail fast if Redis is unreachable
    return client


def stream_exists(client: redis.Redis) -> bool:
    try:
        client.xlen(STREAM_KEY)
        return True
    except redis.ResponseError:
        return False


def group_exists(client: redis.Redis) -> bool:
    try:
        groups = client.xinfo_groups(STREAM_KEY)
        return any(g["name"] == CONSUMER_GROUP for g in groups)
    except redis.ResponseError:
        return False


# ---------------------------------------------------------------------------
# Core provisioning
# ---------------------------------------------------------------------------

def provision(client: redis.Redis, *, reset: bool = False) -> None:
    """Idempotently create stream + consumer group; optionally wipe first."""

    if reset:
        log.warning("--reset: deleting stream '%s'", STREAM_KEY)
        client.delete(STREAM_KEY)

    # Create stream by writing a sentinel entry (auto-trimmed immediately).
    # This ensures the key exists before XGROUP CREATE runs.
    if not stream_exists(client):
        log.info("Creating stream '%s' (sentinel seed)", STREAM_KEY)
        seed_id = client.xadd(STREAM_KEY, {"_init": "1"})
        client.xtrim(STREAM_KEY, maxlen=0, approximate=False)
        log.info("Stream created, seed entry %s trimmed", seed_id)
    else:
        log.info("Stream '%s' already exists — skipping creation", STREAM_KEY)

    # Create consumer group starting at '$' (process only new messages).
    # Use '0' here if you want to replay all existing entries on first run.
    if not group_exists(client):
        log.info(
            "Creating consumer group '%s' on stream '%s'",
            CONSUMER_GROUP,
            STREAM_KEY,
        )
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="$", mkstream=True)
        log.info("Consumer group created")
    else:
        log.info(
            "Consumer group '%s' already exists — skipping creation",
            CONSUMER_GROUP,
        )


def verify(client: redis.Redis) -> None:
    """Log a summary of the current stream / group state."""
    info = client.xinfo_stream(STREAM_KEY)
    groups = client.xinfo_groups(STREAM_KEY)

    log.info("--- Stream info ---")
    log.info("  key        : %s", STREAM_KEY)
    log.info("  length     : %s", info["length"])
    log.info("  last-id    : %s", info["last-generated-id"])

    log.info("--- Consumer groups ---")
    for g in groups:
        log.info(
            "  name=%-30s  consumers=%s  pending=%s  last-delivered=%s",
            g["name"],
            g["consumers"],
            g["pending"],
            g["last-delivered-id"],
        )


# ---------------------------------------------------------------------------
# CLI entry-point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Provision Redis transcript stream")
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete the stream before re-creating (destructive!)",
    )
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Print stream/group state and exit without modifying anything",
    )
    args = parser.parse_args()

    try:
        client = get_client()
    except (redis.ConnectionError, redis.TimeoutError) as exc:
        log.error("Cannot connect to Redis at %s: %s", REDIS_URL, exc)
        sys.exit(1)

    if args.verify_only:
        verify(client)
        return

    provision(client, reset=args.reset)
    verify(client)
    log.info("Provisioning complete ✓")


if __name__ == "__main__":
    main()
