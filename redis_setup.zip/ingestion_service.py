"""
ingestion_service.py — Real-time CSR transcript ingestion via Redis Streams.

Reads from the `transcripts` stream using a consumer group so that:
  - Multiple ingestion workers can share the load (competing consumers).
  - Each message is explicitly ACK'd only after successful processing,
    giving us at-least-once delivery with crash safety.
  - Pending-entry recovery (XAUTOCLAIM) re-processes stale in-flight
    messages after a configurable visibility timeout.
"""

from __future__ import annotations

import logging
import os
import signal
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

import redis

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
STREAM_KEY: str = "transcripts"
CONSUMER_GROUP: str = "transcript-ingestion-group"

# Each worker instance gets a unique name so the group can track per-consumer
# pending entries.
CONSUMER_NAME: str = os.getenv(
    "CONSUMER_NAME", f"worker-{uuid.uuid4().hex[:8]}"
)

BLOCK_MS: int = int(os.getenv("BLOCK_MS", "5000"))         # XREADGROUP block timeout
BATCH_SIZE: int = int(os.getenv("BATCH_SIZE", "10"))        # messages per poll
CLAIM_IDLE_MS: int = int(os.getenv("CLAIM_IDLE_MS", "30000"))  # reclaim after 30 s
SUMMARISE_THRESHOLD: int = int(os.getenv("SUMMARISE_THRESHOLD", "10"))

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


# ---------------------------------------------------------------------------
# Domain types
# ---------------------------------------------------------------------------

@dataclass
class TranscriptTurn:
    message_id: str
    conversation_id: str
    timestamp: str
    speaker: str           # "Agent" | "Member"
    text: str
    intent: str = ""

    @classmethod
    def from_redis(cls, message_id: str, fields: dict[str, str]) -> "TranscriptTurn":
        return cls(
            message_id=message_id,
            conversation_id=fields.get("conversationId", ""),
            timestamp=fields.get("timestamp", ""),
            speaker=fields.get("speaker", ""),
            text=fields.get("text", ""),
            intent=fields.get("intent", ""),
        )


@dataclass
class IngestionStats:
    processed: int = 0
    acked: int = 0
    errors: int = 0
    reclaimed: int = 0
    summarise_triggers: int = 0
    # turn counts per conversation — used to trigger summarisation
    conversation_turns: dict[str, int] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Summarisation trigger
# ---------------------------------------------------------------------------

def maybe_trigger_summarisation(
    turn: TranscriptTurn,
    stats: IngestionStats,
    trigger_fn: Callable[[str], None] | None = None,
) -> None:
    """Increment per-conversation turn count; fire trigger at threshold."""
    conv = turn.conversation_id
    stats.conversation_turns[conv] = stats.conversation_turns.get(conv, 0) + 1
    count = stats.conversation_turns[conv]

    if count > 0 and count % SUMMARISE_THRESHOLD == 0:
        log.info(
            "Summarisation trigger: conversation=%s turns=%d", conv, count
        )
        stats.summarise_triggers += 1
        if trigger_fn:
            trigger_fn(conv)


# ---------------------------------------------------------------------------
# Core service
# ---------------------------------------------------------------------------

class IngestionService:
    def __init__(
        self,
        client: redis.Redis,
        *,
        process_fn: Callable[[TranscriptTurn], None] | None = None,
        summarise_fn: Callable[[str], None] | None = None,
    ) -> None:
        self._r = client
        self._process_fn = process_fn or self._default_process
        self._summarise_fn = summarise_fn
        self._stats = IngestionStats()
        self._running = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Block and process messages until stop() is called."""
        self._running = True
        log.info(
            "Ingestion service starting  consumer=%s  group=%s",
            CONSUMER_NAME,
            CONSUMER_GROUP,
        )
        self._ensure_group()

        while self._running:
            self._reclaim_stale()
            self._poll_and_process()

        log.info("Ingestion service stopped  stats=%s", self._stats)

    def stop(self) -> None:
        self._running = False

    @property
    def stats(self) -> IngestionStats:
        return self._stats

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_group(self) -> None:
        try:
            self._r.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="$", mkstream=True)
            log.info("Consumer group created")
        except redis.ResponseError as exc:
            if "BUSYGROUP" in str(exc):
                log.debug("Consumer group already exists — continuing")
            else:
                raise

    def _poll_and_process(self) -> None:
        """Read a batch from the group and process each entry."""
        try:
            results: list[Any] = self._r.xreadgroup(
                CONSUMER_GROUP,
                CONSUMER_NAME,
                {STREAM_KEY: ">"},   # ">" means: deliver only new messages
                count=BATCH_SIZE,
                block=BLOCK_MS,
            )
        except redis.RedisError as exc:
            log.error("XREADGROUP error: %s", exc)
            time.sleep(1)
            return

        if not results:
            return

        for _stream, messages in results:
            for message_id, fields in messages:
                self._handle(message_id, fields)

    def _handle(self, message_id: str, fields: dict[str, str]) -> None:
        turn = TranscriptTurn.from_redis(message_id, fields)
        try:
            self._process_fn(turn)
            self._stats.processed += 1
            maybe_trigger_summarisation(turn, self._stats, self._summarise_fn)
            self._r.xack(STREAM_KEY, CONSUMER_GROUP, message_id)
            self._stats.acked += 1
        except Exception as exc:  # noqa: BLE001
            # Leave message in PEL; it will be reclaimed after CLAIM_IDLE_MS.
            log.error("Failed to process %s: %s", message_id, exc)
            self._stats.errors += 1

    def _reclaim_stale(self) -> None:
        """Re-deliver messages that have been idle too long (crashed workers)."""
        try:
            # XAUTOCLAIM returns (next_cursor, messages, deleted_ids)
            _cursor, messages, _deleted = self._r.xautoclaim(
                STREAM_KEY,
                CONSUMER_GROUP,
                CONSUMER_NAME,
                min_idle_time=CLAIM_IDLE_MS,
                start_id="0-0",
                count=BATCH_SIZE,
            )
        except redis.ResponseError:
            # Redis < 6.2 doesn't have XAUTOCLAIM — gracefully degrade.
            return

        for message_id, fields in messages:
            log.warning("Reclaiming stale message %s", message_id)
            self._stats.reclaimed += 1
            self._handle(message_id, fields)

    @staticmethod
    def _default_process(turn: TranscriptTurn) -> None:
        log.info(
            "[%s] %s: %s", turn.conversation_id, turn.speaker, turn.text[:80]
        )


# ---------------------------------------------------------------------------
# Entry-point
# ---------------------------------------------------------------------------

def main() -> None:
    client = redis.from_url(REDIS_URL, decode_responses=True)
    service = IngestionService(client)

    def _shutdown(_sig: int, _frame: Any) -> None:
        log.info("Shutdown signal received")
        service.stop()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    service.run()


if __name__ == "__main__":
    main()
