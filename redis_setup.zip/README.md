# Transcript Redis Stream — Configuration & Setup

## Stream Configuration

| Setting | Value |
|---|---|
| Stream name | `transcripts` |
| Consumer group | `transcript-ingestion-group` |
| Read strategy | `XREADGROUP` with `>` (new messages only) |
| Pending recovery | `XAUTOCLAIM` after 30s idle (`CLAIM_IDLE_MS`) |
| Batch size | 10 messages per poll (`BATCH_SIZE`) |
| Block timeout | 5000ms per poll cycle (`BLOCK_MS`) |

---

## Retention Strategy

Redis Streams do not auto-expire entries by default. This stream uses **maxlen trimming** to cap memory usage.

Trimming is applied at write time via `XADD` with `MAXLEN`:

```
XADD transcripts MAXLEN ~ 100000 * field value ...
```

The `~` means approximate trimming — Redis trims in bulk at natural boundaries, which is significantly cheaper than exact trimming and sufficient for this use case.

### Rationale

| Option | Decision |
|---|---|
| **Maxlen ~100,000** | Keeps roughly the last ~100k turns in memory. At ~200 bytes per entry that's ~20MB — well within Redis limits. |
| Approximate (`~`) not exact | Exact trimming (`=`) is expensive at high throughput; approximate is fine for a streaming pipeline. |
| No TTL-based expiry | Redis TTL works on keys, not individual stream entries. Maxlen is the correct mechanism here. |
| No persistence (`appendonly no`) | Dev environment only. Production should enable AOF or RDB snapshots. |

---

## Event Schema

Every entry written to the `transcripts` stream must conform to this schema:

| Field | Type | Values | Required |
|---|---|---|---|
| `conversationId` | string | Any unique conversation identifier | ✅ |
| `timestamp` | string | Unix epoch (seconds or ms) | ✅ |
| `speaker` | string | `Agent` or `Member` | ✅ |
| `text` | string | Transcript turn text | ✅ |
| `intent` | string | Detected intent label, or `""` | ✅ |

### Example XADD

```bash
XADD transcripts * \
  conversationId 123 \
  timestamp 1700000000 \
  speaker Agent \
  text "Hello, how can I help?" \
  intent greeting
```

---

## Local Development Setup

### Prerequisites
- Docker Desktop (running)
- Python 3.12+

### Install Python dependencies

```bash
pip install redis fakeredis pytest
```

### Start Redis

```bash
docker compose up redis -d
```

### Provision stream + consumer group

```bash
python redis_setup.py
```

Verify state at any time:

```bash
python redis_setup.py --verify-only
```

Reset (wipe and recreate):

```bash
python redis_setup.py --reset
```

### Run ingestion worker

```bash
python ingestion_service.py
```

### Run tests

```bash
pytest test_ingestion_service.py -v
```

### RedisInsight GUI (optional)

```bash
docker compose up redisinsight -d
# Open http://localhost:5540
# Connect to redis:6379
```

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `REDIS_URL` | `redis://localhost:6379` | Redis connection string |
| `CONSUMER_NAME` | `worker-{random}` | Unique name for this worker instance |
| `BLOCK_MS` | `5000` | XREADGROUP block timeout in ms |
| `BATCH_SIZE` | `10` | Messages per poll cycle |
| `CLAIM_IDLE_MS` | `30000` | Reclaim pending messages after this idle time |
| `SUMMARISE_THRESHOLD` | `10` | Turns per conversation before summarisation triggers |

---

## Files

| File | Purpose |
|---|---|
| `redis_setup.py` | Provisions stream and consumer group |
| `ingestion_service.py` | Consumer worker — reads, processes, ACKs |
| `test_ingestion_service.py` | 13 acceptance-criteria tests (fakeredis) |
| `docker-compose.yml` | Redis + RedisInsight + provisioner + worker |
| `Dockerfile.dev` | Dev image for containerised workers |

---

## Production Considerations

- Enable Redis persistence (`appendonly yes` or RDB snapshots)
- Set `MAXLEN` trimming on `XADD` calls in the bridge service
- Run multiple ingestion workers (`docker compose up --scale ingestion=3`) for throughput
- Monitor PEL size via `XPENDING transcripts transcript-ingestion-group` — a growing PEL indicates processing failures
