"""
test_ingestion_service.py — Consumer-group behaviour tests.

Acceptance criteria:
  AC-1  Normal operation: messages are processed and ACK'd exactly once.
  AC-2  Mid-stream restart: service resumes from pending entries, not head.
  AC-3  Pointer accuracy on failure: failed message stays in PEL, not lost.
  AC-4  Idempotency: re-delivering a pending entry does not double-process.
  AC-5  Summarisation trigger: fires after every N turns per conversation.
  AC-6  Stale reclaim: messages idle beyond threshold are re-delivered to
        an active consumer.
  AC-7  Competing consumers: two workers split a batch without overlap.
"""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, call, patch

import fakeredis
import pytest

from ingestion_service import (
    CONSUMER_GROUP,
    STREAM_KEY,
    SUMMARISE_THRESHOLD,
    IngestionService,
    IngestionStats,
    TranscriptTurn,
    maybe_trigger_summarisation,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def make_client() -> fakeredis.FakeRedis:
    """Return a fresh in-memory Redis instance with Streams support."""
    return fakeredis.FakeRedis(decode_responses=True, version=(7, 0, 0))


def seed_stream(client: fakeredis.FakeRedis, n: int = 5, conv: str = "c1") -> list[str]:
    """Write *n* transcript turns and return their stream IDs."""
    ids = []
    for i in range(n):
        msg_id = client.xadd(
            STREAM_KEY,
            {
                "conversationId": conv,
                "timestamp": str(1_000_000 + i),
                "speaker": "Agent" if i % 2 == 0 else "Member",
                "text": f"turn {i}",
                "intent": "greeting" if i == 0 else "",
            },
        )
        ids.append(msg_id)
    return ids


def make_service(
    client: fakeredis.FakeRedis,
    *,
    process_fn=None,
    summarise_fn=None,
) -> IngestionService:
    svc = IngestionService(client, process_fn=process_fn, summarise_fn=summarise_fn)
    # Override blocking poll to avoid infinite waits in tests.
    return svc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def drain(service: IngestionService, client: fakeredis.FakeRedis) -> None:
    """Run one provisioning pass + one poll cycle then stop."""
    service._ensure_group()
    service._poll_and_process()


def pending_count(client: fakeredis.FakeRedis) -> int:
    info = client.xpending(STREAM_KEY, CONSUMER_GROUP)
    return info["pending"]


# ---------------------------------------------------------------------------
# AC-1  Normal operation
# ---------------------------------------------------------------------------


class TestNormalOperation:
    def test_all_messages_processed_and_acked(self):
        client = make_client()
        processed = []

        seed_stream(client, n=5)

        # Create group BEFORE reading so '>' returns all entries.
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        svc = make_service(client, process_fn=lambda t: processed.append(t.message_id))
        drain(svc, client)

        assert len(processed) == 5
        assert svc.stats.processed == 5
        assert svc.stats.acked == 5
        assert pending_count(client) == 0, "PEL should be empty after successful ACKs"

    def test_turn_fields_are_mapped_correctly(self):
        client = make_client()
        turns: list[TranscriptTurn] = []

        client.xadd(
            STREAM_KEY,
            {
                "conversationId": "conv-42",
                "timestamp": "1700000000",
                "speaker": "Agent",
                "text": "How can I help?",
                "intent": "greeting",
            },
        )
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        svc = make_service(client, process_fn=turns.append)
        drain(svc, client)

        assert len(turns) == 1
        t = turns[0]
        assert t.conversation_id == "conv-42"
        assert t.speaker == "Agent"
        assert t.text == "How can I help?"
        assert t.intent == "greeting"


# ---------------------------------------------------------------------------
# AC-2  Mid-stream restart
# ---------------------------------------------------------------------------


class TestMidStreamRestart:
    def test_pending_entries_redelivered_after_restart(self):
        """
        Pending entries owned by a dead consumer are reclaimed via XAUTOCLAIM
        (min_idle_time=0 in tests), then ACK'd by the recovery worker.
        """
        client = make_client()
        seed_stream(client, n=4)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        # Simulate crashed worker: delivered but never ACK'd.
        client.xreadgroup(CONSUMER_GROUP, "crashed-worker", {STREAM_KEY: ">"}, count=4)
        assert pending_count(client) == 4, "Messages should be pending after crash"

        # Recovery: XAUTOCLAIM with min_idle_time=0 immediately transfers ownership.
        recovered = []
        _cursor, messages, _deleted = client.xautoclaim(
            STREAM_KEY,
            CONSUMER_GROUP,
            "recovery-worker",
            min_idle_time=0,
            start_id="0-0",
            count=10,
        )
        for msg_id, fields in messages:
            recovered.append(msg_id)
            client.xack(STREAM_KEY, CONSUMER_GROUP, msg_id)

        assert len(recovered) == 4
        assert pending_count(client) == 0

    def test_new_messages_after_restart_are_not_reprocessed(self):
        """Messages delivered and ACK'd before restart must not appear on recovery."""
        client = make_client()
        ids = seed_stream(client, n=3)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        processed = []
        svc = make_service(client, process_fn=lambda t: processed.append(t.message_id))
        drain(svc, client)

        assert len(processed) == 3

        # Simulate restart — read pending (id="0") should return nothing.
        recovery_results = client.xreadgroup(
            CONSUMER_GROUP, "new-worker", {STREAM_KEY: "0"}, count=10
        )
        pending_on_restart = [
            msg_id
            for _stream, msgs in recovery_results
            for msg_id, _ in msgs
        ]
        assert pending_on_restart == [], "No pending entries should remain after clean ACKs"


# ---------------------------------------------------------------------------
# AC-3  Pointer accuracy on failure
# ---------------------------------------------------------------------------


class TestPointerAccuracyOnFailure:
    def test_failed_message_stays_in_pel(self):
        client = make_client()
        seed_stream(client, n=3)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        call_count = {"n": 0}

        def flaky(turn: TranscriptTurn) -> None:
            call_count["n"] += 1
            if call_count["n"] == 2:
                raise ValueError("transient error on turn 2")

        svc = make_service(client, process_fn=flaky)
        drain(svc, client)

        assert svc.stats.processed == 2   # turns 1 & 3
        assert svc.stats.errors == 1       # turn 2 errored
        assert svc.stats.acked == 2        # only successful ones ACK'd
        assert pending_count(client) == 1  # turn 2 still in PEL

    def test_successful_messages_not_affected_by_sibling_failure(self):
        client = make_client()
        seed_stream(client, n=5)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        failed_ids = []

        def fail_even(turn: TranscriptTurn) -> None:
            idx = int(turn.text.split()[-1])
            if idx % 2 == 0:
                failed_ids.append(turn.message_id)
                raise RuntimeError("even turn failure")

        svc = make_service(client, process_fn=fail_even)
        drain(svc, client)

        assert svc.stats.acked == 2       # turns 1, 3 (odd indices) succeed
        assert len(failed_ids) == 3        # turns 0, 2, 4 (even indices) fail


# ---------------------------------------------------------------------------
# AC-4  Idempotency
# ---------------------------------------------------------------------------


class TestIdempotency:
    def test_redelivered_pending_entry_processed_once(self):
        """Simulate a message redelivered from PEL and verify no double side-effects."""
        client = make_client()
        msg_id = client.xadd(
            STREAM_KEY,
            {"conversationId": "c1", "timestamp": "1", "speaker": "Agent", "text": "hi", "intent": ""},
        )
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        side_effects = []

        def record(turn: TranscriptTurn) -> None:
            side_effects.append(turn.conversation_id)

        svc = make_service(client, process_fn=record)

        # First delivery: success + ACK.
        drain(svc, client)
        assert len(side_effects) == 1
        assert pending_count(client) == 0

        # Re-inject the same logical content (new stream ID, same payload).
        client.xadd(
            STREAM_KEY,
            {"conversationId": "c1", "timestamp": "1", "speaker": "Agent", "text": "hi", "intent": ""},
        )
        drain(svc, client)

        # A new ID means it counts as a new delivery; total should be 2.
        # The key assertion: no message is acked more than once per unique ID.
        assert len(side_effects) == 2
        assert pending_count(client) == 0


# ---------------------------------------------------------------------------
# AC-5  Summarisation trigger
# ---------------------------------------------------------------------------


class TestSummarisationTrigger:
    def test_trigger_fires_at_threshold(self):
        trigger_mock = MagicMock()
        stats = IngestionStats()

        for i in range(SUMMARISE_THRESHOLD):
            turn = TranscriptTurn(
                message_id=str(i),
                conversation_id="conv-99",
                timestamp=str(i),
                speaker="Agent",
                text=f"turn {i}",
            )
            maybe_trigger_summarisation(turn, stats, trigger_mock)

        trigger_mock.assert_called_once_with("conv-99")
        assert stats.summarise_triggers == 1

    def test_trigger_fires_on_each_multiple(self):
        trigger_mock = MagicMock()
        stats = IngestionStats()

        for i in range(SUMMARISE_THRESHOLD * 3):
            turn = TranscriptTurn(
                message_id=str(i),
                conversation_id="conv-77",
                timestamp=str(i),
                speaker="Member",
                text=f"turn {i}",
            )
            maybe_trigger_summarisation(turn, stats, trigger_mock)

        assert trigger_mock.call_count == 3
        assert stats.summarise_triggers == 3

    def test_trigger_isolated_per_conversation(self):
        trigger_mock = MagicMock()
        stats = IngestionStats()

        # Two conversations interleaved; each should trigger independently.
        for conv in ["A", "B"]:
            for i in range(SUMMARISE_THRESHOLD):
                turn = TranscriptTurn(
                    message_id=f"{conv}-{i}",
                    conversation_id=conv,
                    timestamp=str(i),
                    speaker="Agent",
                    text=f"turn {i}",
                )
                maybe_trigger_summarisation(turn, stats, trigger_mock)

        assert trigger_mock.call_count == 2
        trigger_mock.assert_any_call("A")
        trigger_mock.assert_any_call("B")

    def test_no_trigger_below_threshold(self):
        trigger_mock = MagicMock()
        stats = IngestionStats()

        for i in range(SUMMARISE_THRESHOLD - 1):
            turn = TranscriptTurn(
                message_id=str(i),
                conversation_id="conv-silent",
                timestamp=str(i),
                speaker="Agent",
                text=f"turn {i}",
            )
            maybe_trigger_summarisation(turn, stats, trigger_mock)

        trigger_mock.assert_not_called()


# ---------------------------------------------------------------------------
# AC-6  Stale reclaim
# ---------------------------------------------------------------------------


class TestStaleReclaim:
    def test_reclaim_redelivers_idle_messages(self):
        """
        Fakeredis supports XAUTOCLAIM; verify that the service reclaims a
        message previously delivered to a crashed consumer.
        """
        client = make_client()
        seed_stream(client, n=2)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        # Deliver to a "crashed" consumer without ACKing.
        client.xreadgroup(CONSUMER_GROUP, "dead-worker", {STREAM_KEY: ">"}, count=2)

        reclaimed = []
        svc = make_service(client, process_fn=lambda t: reclaimed.append(t.message_id))

        # Patch min_idle_time to 0 so we can reclaim immediately in tests.
        with patch("ingestion_service.CLAIM_IDLE_MS", 0):
            svc._ensure_group()
            svc._reclaim_stale()

        assert len(reclaimed) == 2
        assert svc.stats.reclaimed == 2
        assert pending_count(client) == 0


# ---------------------------------------------------------------------------
# AC-7  Competing consumers
# ---------------------------------------------------------------------------


class TestCompetingConsumers:
    def test_two_workers_share_messages_without_overlap(self):
        """
        Two services reading from the same group should receive disjoint sets.
        """
        client = make_client()
        seed_stream(client, n=10)
        client.xgroup_create(STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True)

        worker1_ids: list[str] = []
        worker2_ids: list[str] = []

        results1 = client.xreadgroup(
            CONSUMER_GROUP, "worker-1", {STREAM_KEY: ">"}, count=5
        )
        results2 = client.xreadgroup(
            CONSUMER_GROUP, "worker-2", {STREAM_KEY: ">"}, count=5
        )

        for _stream, msgs in results1:
            for msg_id, _ in msgs:
                worker1_ids.append(msg_id)

        for _stream, msgs in results2:
            for msg_id, _ in msgs:
                worker2_ids.append(msg_id)

        assert len(worker1_ids) == 5
        assert len(worker2_ids) == 5
        assert set(worker1_ids).isdisjoint(set(worker2_ids)), (
            "Workers received overlapping messages!"
        )
