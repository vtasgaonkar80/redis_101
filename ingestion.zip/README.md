# CSR Transcript Ingestion Service

Real-time Redis Stream consumer that ingests CSR transcript turns with
exactly-once delivery semantics, crash recovery, and pointer-safe resumption.

---

## Architecture

```
Redis Stream  ──XREAD──►  Ingestion Loop  ──process_turn()──►  Your Store / Pipeline
  (turns)                  (pointer safe)
                                │
                           XSET pointer
                          (atomic, per turn)
```

- **Stream key** : `calls:transcript`
- **Pointer key** : `calls:ingestion_pointer`  (last successfully processed entry ID)

---

## Acceptance Criteria coverage

| # | Criterion | How it's met |
|---|-----------|-------------|
| 1 | No dropped turns | XREAD from persisted pointer; retry on failure |
| 2 | Pointer = last success | Pointer written **after** `process_turn()` returns |
| 3 | Resume after restart | `load_pointer()` reads from Redis on startup |
| 4 | Idempotent processing | `process_turn` contract; example uses upsert pattern |
| 5 | New-data detection via unread entries | `should_trigger_summarization` counts new entries, not totals |

---

## Setup

```bash
pip install redis fakeredis pytest
```

## Run

```bash
python ingestion_service.py
```

## Test

```bash
pytest test_ingestion_service.py -v
```

---

## Customising `process_turn`

Replace `example_process_turn` with your own function:

```python
def my_processor(entry_id: str, fields: dict) -> None:
    # MUST be idempotent — upsert, not blind insert
    db.upsert(id=entry_id, speaker=fields["speaker"], text=fields["text"])
    # Raise ProcessingError(entry_id, "reason") for retryable failures
```

Then pass it to `run_ingestion`:

```python
run_ingestion(r=redis_client, process_turn=my_processor)
```

---

## Configuration (env-friendly constants in `ingestion_service.py`)

| Constant | Default | Description |
|----------|---------|-------------|
| `STREAM_KEY` | `calls:transcript` | Redis Stream to consume |
| `POINTER_KEY` | `calls:ingestion_pointer` | Pointer persistence key |
| `POLL_INTERVAL_MS` | `500` | Block-wait timeout on idle stream |
