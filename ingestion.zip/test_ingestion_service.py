"""
Tests for the CSR Transcript Ingestion Service
===============================================
Covers all acceptance criteria:
  AC1 — No dropped turns under normal operation, retries, or restarts.
  AC2 — Pointer always reflects the last successfully processed entry.
  AC3 — Ingestion resumes from persisted pointer after restart.
  AC4 — Processing is idempotent / duplicate-safe.
  AC5 — New data detection based on unread entries, not total-turn count.
"""

import threading
import time
from unittest.mock import MagicMock, call, patch

import pytest
import fakeredis

from ingestion_service import (
    INITIAL_POINTER,
    ProcessingError,
    example_process_turn,
    load_pointer,
    run_ingestion,
    save_pointer,
    should_trigger_summarization,
)


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def r():
    """In-memory fakeredis instance, reset between tests."""
    return fakeredis.FakeRedis()


def make_stop(after_cycles: int = 1):
    """Returns a stop_event that auto-sets after N loop wakeups."""
    event = threading.Event()
    counter = {"n": 0}

    original_is_set = event.is_set

    def patched_is_set():
        counter["n"] += 1
        if counter["n"] > after_cycles:
            event.set()
        return original_is_set()

    event.is_set = patched_is_set
    return event


# ─── Pointer helpers ──────────────────────────────────────────────────────────

class TestPointer:
    def test_load_returns_initial_when_missing(self, r):
        assert load_pointer(r) == INITIAL_POINTER

    def test_load_returns_saved_value(self, r):
        r.set("calls:ingestion_pointer", "1700000000000-0")
        assert load_pointer(r) == "1700000000000-0"

    def test_save_pointer_writes_to_redis(self, r):
        with r.pipeline() as pipe:
            save_pointer(pipe, "1234-0")
            pipe.execute()
        assert r.get("calls:ingestion_pointer").decode() == "1234-0"


# ─── AC1: No dropped turns ────────────────────────────────────────────────────

class TestNoDroppedTurns:
    def test_all_entries_processed_in_order(self, r):
        # Seed 5 turns
        ids = []
        for i in range(5):
            eid = r.xadd("calls:transcript", {"speaker": "agent", "text": f"turn {i}"})
            ids.append(eid.decode() if isinstance(eid, bytes) else eid)

        processed = []
        stop = threading.Event()

        def capture(entry_id, fields):
            processed.append(entry_id)
            if len(processed) == 5:
                stop.set()

        t = threading.Thread(
            target=run_ingestion,
            kwargs=dict(r=r, process_turn=capture, stop_event=stop),
            daemon=True,
        )
        t.start()
        t.join(timeout=5)

        assert processed == ids, "All entry IDs must be processed in order"

    def test_no_entries_skipped_after_restart(self, r):
        """Simulate a restart mid-stream (AC1 + AC3)."""
        # Add 6 turns, process first 3, simulate restart, expect turns 4-6
        all_ids = []
        for i in range(6):
            eid = r.xadd("calls:transcript", {"text": f"turn {i}"})
            all_ids.append(eid.decode() if isinstance(eid, bytes) else eid)

        # First run: process 3 turns
        first_run = []
        stop1 = threading.Event()

        def first_processor(entry_id, fields):
            first_run.append(entry_id)
            if len(first_run) == 3:
                stop1.set()

        t1 = threading.Thread(
            target=run_ingestion,
            kwargs=dict(r=r, process_turn=first_processor, stop_event=stop1),
            daemon=True,
        )
        t1.start()
        t1.join(timeout=5)

        # Verify pointer was advanced
        assert r.get("calls:ingestion_pointer").decode() == all_ids[2]

        # Second run: should resume from turn 4 (index 3)
        second_run = []
        stop2 = threading.Event()

        def second_processor(entry_id, fields):
            second_run.append(entry_id)
            if len(second_run) == 3:
                stop2.set()

        t2 = threading.Thread(
            target=run_ingestion,
            kwargs=dict(r=r, process_turn=second_processor, stop_event=stop2),
            daemon=True,
        )
        t2.start()
        t2.join(timeout=5)

        assert second_run == all_ids[3:], "After restart must resume from last pointer"


# ─── AC2: Pointer reflects last successfully processed entry ──────────────────

class TestPointerAccuracy:
    def test_pointer_set_only_after_success(self, r):
        eid = r.xadd("calls:transcript", {"text": "hello"})
        eid_str = eid.decode() if isinstance(eid, bytes) else eid

        stop = threading.Event()

        def good_processor(entry_id, fields):
            stop.set()

        t = threading.Thread(
            target=run_ingestion,
            kwargs=dict(r=r, process_turn=good_processor, stop_event=stop),
            daemon=True,
        )
        t.start()
        t.join(timeout=5)

        assert r.get("calls:ingestion_pointer").decode() == eid_str

    def test_pointer_not_advanced_on_failure(self, r):
        r.xadd("calls:transcript", {"text": "boom"})

        stop = threading.Event()
        call_count = {"n": 0}

        def failing_processor(entry_id, fields):
            call_count["n"] += 1
            if call_count["n"] == 1:
                stop.set()
                raise ProcessingError(entry_id, "simulated failure")

        t = threading.Thread(
            target=run_ingestion,
            kwargs=dict(r=r, process_turn=failing_processor, stop_event=stop),
            daemon=True,
        )
        t.start()
        t.join(timeout=5)

        # Pointer must remain at initial (never advanced past failed entry)
        saved = r.get("calls:ingestion_pointer")
        assert saved is None or saved.decode() == INITIAL_POINTER


# ─── AC3: Resume from persisted pointer after restart (covered above) ─────────
# See TestNoDroppedTurns.test_no_entries_skipped_after_restart


# ─── AC4: Idempotent / duplicate-safe ─────────────────────────────────────────

class TestIdempotency:
    def test_example_processor_can_run_twice_without_error(self, r, caplog):
        """example_process_turn must not raise when called twice for same entry."""
        import logging
        with caplog.at_level(logging.INFO):
            example_process_turn("123-0", {"speaker": "agent", "text": "hi", "call_id": "c1"})
            example_process_turn("123-0", {"speaker": "agent", "text": "hi", "call_id": "c1"})
        # No exception = idempotent behaviour confirmed


# ─── AC5: Summarization triggered by new entries, not total count ─────────────

class TestSummarizationTrigger:
    def test_triggers_when_new_entries_present(self):
        assert should_trigger_summarization(["e1", "e2"], total_turns=2) is True

    def test_does_not_trigger_when_no_new_entries(self):
        assert should_trigger_summarization([], total_turns=100) is False

    def test_triggers_with_single_new_entry_and_zero_total(self):
        assert should_trigger_summarization(["e1"], total_turns=0) is True
