"""
Real-time CSR Transcript Ingestion Service
==========================================
Consumes Redis Stream events one turn at a time from the last processed pointer,
ensuring no transcript turn is missed, duplicated, or skipped.

Redis layout:
  - Stream key : STREAM_KEY   (e.g. "calls:{call_id}:transcript")
  - Pointer key: POINTER_KEY  (e.g. "calls:{call_id}:ingestion_pointer")

Pointer semantics:
  - "0-0"          → start of stream (first run / explicit reset)
  - "<ms>-<seq>"   → last successfully processed Redis Stream entry ID
"""

import logging
import time
from typing import Callable

import redis

logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────

STREAM_KEY       = "calls:transcript"        # Redis Stream containing transcript turns
POINTER_KEY      = "calls:ingestion_pointer" # Redis key storing the last processed ID
POLL_INTERVAL_MS = 500                       # Milliseconds to block-wait on XREAD
INITIAL_POINTER  = "0-0"                     # Start-of-stream sentinel


# ─── Pointer helpers ──────────────────────────────────────────────────────────

def load_pointer(r: redis.Redis) -> str:
    """
    Load the last committed pointer from Redis.
    Returns INITIAL_POINTER if this is the first run.
    """
    raw = r.get(POINTER_KEY)
    if raw is None:
        logger.info("No persisted pointer found — starting from beginning of stream.")
        return INITIAL_POINTER
    pointer = raw.decode() if isinstance(raw, bytes) else raw
    logger.info("Resuming from pointer: %s", pointer)
    return pointer


def save_pointer(pipe: redis.client.Pipeline, pointer: str) -> None:
    """
    Queue a pointer update inside an existing pipeline / transaction.
    Call pipe.execute() after this to commit atomically.
    """
    pipe.set(POINTER_KEY, pointer)


# ─── Core ingestion loop ───────────────────────────────────────────────────────

def run_ingestion(
    r: redis.Redis,
    process_turn: Callable[[str, dict], None],
    *,
    stream_key: str = STREAM_KEY,
    pointer_key: str = POINTER_KEY,
    poll_interval_ms: int = POLL_INTERVAL_MS,
    stop_event=None,          # optional threading.Event for graceful shutdown
) -> None:
    """
    Main ingestion loop — processes one transcript turn per cycle.

    Each cycle:
      1. Block on XREAD until the next turn arrives (or timeout elapses).
      2. Decode the single entry and call process_turn(entry_id, fields).
      3. Atomically persist the pointer after successful processing.
      4. On ProcessingError, back off and retry the same entry.

    The loop blocks (via XREAD BLOCK) when the stream is caught up, so it
    consumes near-zero CPU at idle.

    Args:
        r               : Connected redis.Redis client.
        process_turn    : Callback invoked for each transcript turn.
                          Receives (entry_id: str, fields: dict).
                          Must be idempotent — it may be called again on retry.
        stream_key      : Redis Stream key to consume.
        pointer_key     : Redis key used to persist the read pointer.
        poll_interval_ms: Milliseconds to block-wait when the stream is caught up.
        stop_event      : Optional threading.Event; loop exits when set.
    """
    pointer = load_pointer(r)

    while not (stop_event and stop_event.is_set()):
        try:
            # ── 1. Block until the next turn arrives ──────────────────────────
            results = r.xread(
                {stream_key: pointer},
                count=1,
                block=poll_interval_ms,
            )

            if not results:
                # Timeout — no new turn yet, loop and wait again.
                continue

            # results: [ (stream_key_bytes, [(entry_id_bytes, {field: value})]) ]
            _stream_name, entries = results[0]
            entry_id_raw, raw_fields = entries[0]

            # ── 2. Decode entry ───────────────────────────────────────────────
            entry_id = (
                entry_id_raw.decode() if isinstance(entry_id_raw, bytes) else entry_id_raw
            )
            fields = {
                (k.decode() if isinstance(k, bytes) else k): (
                    v.decode() if isinstance(v, bytes) else v
                )
                for k, v in raw_fields.items()
            }

            # ── 3. Process, then atomically advance pointer ───────────────────
            process_turn(entry_id, fields)

            with r.pipeline() as pipe:
                save_pointer(pipe, entry_id)
                pipe.execute()

            pointer = entry_id
            logger.debug("Pointer advanced to %s", pointer)

        except ProcessingError as exc:
            # ── 4. Retryable failure — pointer stays, retry same entry ────────
            logger.error(
                "Processing failed at entry %s: %s — retrying in 1 s",
                exc.entry_id, exc,
            )
            time.sleep(1)

        except redis.RedisError as exc:
            logger.error("Redis error: %s — retrying in 2 s", exc)
            time.sleep(2)


# ─── Custom exception ─────────────────────────────────────────────────────────

class ProcessingError(Exception):
    """Raised by process_turn implementations to signal a retryable failure."""
    def __init__(self, entry_id: str, message: str):
        super().__init__(message)
        self.entry_id = entry_id


# ─── Downstream trigger helper ────────────────────────────────────────────────

def should_trigger_summarization(new_entries: list, _total_turns: int) -> bool:
    """
    Trigger summarization based on the presence of newly received entries,
    NOT on total turn count alone (acceptance criterion #5).
    """
    return len(new_entries) > 0


# ─── Example process_turn implementation ──────────────────────────────────────

def example_process_turn(entry_id: str, fields: dict) -> None:
    """
    Placeholder turn processor.  Replace with your real business logic.

    This function MUST be idempotent: if called twice with the same entry_id
    it should produce the same result without side-effects (e.g. upsert, not insert).
    """
    speaker  = fields.get("speaker", "unknown")
    text     = fields.get("text", "")
    call_id  = fields.get("call_id", "unknown")

    logger.info("[%s] %s — %s: %s", entry_id, call_id, speaker, text)

    # TODO: upsert into your transcript store, emit to downstream pipeline, etc.
    # Raise ProcessingError(entry_id, "reason") to trigger a retry from here.


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import threading

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    )

    redis_client = redis.Redis(host="localhost", port=6379, db=0)

    stop = threading.Event()

    try:
        logger.info("Starting ingestion service…")
        run_ingestion(
            r=redis_client,
            process_turn=example_process_turn,
            stop_event=stop,
        )
    except KeyboardInterrupt:
        logger.info("Shutting down gracefully…")
        stop.set()
