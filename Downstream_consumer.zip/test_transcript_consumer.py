"""
test_transcript_consumer.py

Acceptance tests for TranscriptConsumer.

AC-1  Normal consumption   – handler is called for every message; all are ACK'd.
AC-2  Independent offsets  – two groups on the same stream each receive all messages.
AC-3  Crash recovery       – pending messages for a consumer are re-processed on restart.
AC-4  Idempotent ACK       – processing the same message twice does not raise an error.
AC-5  Dead-letter routing  – a persistently failing handler moves the message to the
                             dead-letter stream and does not block the consumer.
"""

from __future__ import annotations

import threading
import time
from unittest.mock import MagicMock, patch

import fakeredis
import pytest

from transcript_consumer import (
    DEFAULT_MAX_RETRIES,
    STREAM_KEY,
    TranscriptConsumer,
    TranscriptEvent,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_FIELDS: dict[bytes, bytes] = {
    b"conversation_id": b"conv-1",
    b"turn_id": b"turn-1",
    b"speaker": b"agent",
    b"text": b"Hello, how can I help?",
    b"timestamp": b"2024-01-01T00:00:00Z",
    b"sequence": b"1",
}


def _seed_stream(r: fakeredis.FakeRedis, n: int = 3) -> list[str]:
    """Add `n` transcript turns to the stream; return their IDs."""
    ids = []
    for i in range(n):
        fields = {k: v for k, v in SAMPLE_FIELDS.items()}
        fields[b"turn_id"] = f"turn-{i}".encode()
        fields[b"sequence"] = str(i).encode()
        ids.append(r.xadd(STREAM_KEY, fields))
    return [sid.decode() if isinstance(sid, bytes) else sid for sid in ids]


def _make_consumer(
    r: fakeredis.FakeRedis,
    handler=None,
    *,
    group: str = "test-group",
    name: str = "consumer-1",
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> TranscriptConsumer:
    return TranscriptConsumer(
        redis_client=r,
        group_name=group,
        consumer_name=name,
        handler=handler or (lambda e: None),
        block_ms=0,         # non-blocking in tests
        batch_size=10,
        max_retries=max_retries,
    )


def _drain(consumer: TranscriptConsumer, iterations: int = 5) -> None:
    """Run the fetch-process loop for a fixed number of iterations."""
    consumer._ensure_group()
    consumer._recover_pending()
    for _ in range(iterations):
        msgs = consumer._fetch_new(count=10)
        if not msgs:
            break
        for sid, fields in msgs:
            consumer._process_with_retry(sid, fields)


# ---------------------------------------------------------------------------
# AC-1  Normal consumption
# ---------------------------------------------------------------------------

class TestNormalConsumption:
    def test_handler_called_for_every_message(self):
        r = fakeredis.FakeRedis()
        ids = _seed_stream(r, n=4)
        received: list[TranscriptEvent] = []

        consumer = _make_consumer(r, handler=received.append)
        _drain(consumer)

        assert len(received) == 4

    def test_all_messages_acknowledged(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=3)

        consumer = _make_consumer(r)
        _drain(consumer)

        # Pending count should be zero after successful processing
        pending = r.xpending(STREAM_KEY, "test-group")
        assert pending["pending"] == 0

    def test_event_fields_deserialise_correctly(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)
        received: list[TranscriptEvent] = []

        consumer = _make_consumer(r, handler=received.append)
        _drain(consumer)

        evt = received[0]
        assert evt.conversation_id == "conv-1"
        assert evt.speaker == "agent"
        assert evt.sequence == 0


# ---------------------------------------------------------------------------
# AC-2  Independent offsets (two consumer groups, same stream)
# ---------------------------------------------------------------------------

class TestIndependentOffsets:
    def test_two_groups_each_receive_all_messages(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=5)

        received_a: list[TranscriptEvent] = []
        received_b: list[TranscriptEvent] = []

        consumer_a = _make_consumer(r, handler=received_a.append, group="group-a")
        consumer_b = _make_consumer(r, handler=received_b.append, group="group-b")

        _drain(consumer_a)
        _drain(consumer_b)

        assert len(received_a) == 5
        assert len(received_b) == 5

    def test_ack_in_one_group_does_not_affect_other(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=3)

        received_b: list[TranscriptEvent] = []

        # group-a drains and ACKs everything
        consumer_a = _make_consumer(r, group="group-a")
        _drain(consumer_a)

        # group-b should still receive all 3 messages independently
        consumer_b = _make_consumer(r, handler=received_b.append, group="group-b")
        _drain(consumer_b)

        assert len(received_b) == 3

    def test_new_messages_delivered_to_both_groups(self):
        r = fakeredis.FakeRedis()

        received_a: list[TranscriptEvent] = []
        received_b: list[TranscriptEvent] = []

        consumer_a = _make_consumer(r, handler=received_a.append, group="group-a")
        consumer_b = _make_consumer(r, handler=received_b.append, group="group-b")

        # Groups created before messages arrive
        _drain(consumer_a)
        _drain(consumer_b)

        # Now add messages
        _seed_stream(r, n=2)
        _drain(consumer_a)
        _drain(consumer_b)

        assert len(received_a) == 2
        assert len(received_b) == 2


# ---------------------------------------------------------------------------
# AC-3  Crash recovery (pending messages re-processed on restart)
# ---------------------------------------------------------------------------

class TestCrashRecovery:
    def test_pending_messages_reprocessed_after_simulated_crash(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=3)

        # Simulate first consumer: fetch messages but crash before ACK
        r.xgroup_create(STREAM_KEY, "test-group", id="0", mkstream=True)
        entries = r.xreadgroup(
            groupname="test-group",
            consumername="consumer-1",
            streams={STREAM_KEY: ">"},
            count=10,
        )
        # Do NOT ACK — simulating a crash

        # On restart, consumer should recover and process all pending messages
        received: list[TranscriptEvent] = []
        consumer = _make_consumer(r, handler=received.append)
        consumer._recover_pending()

        assert len(received) == 3

    def test_all_recovered_messages_acknowledged(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=2)

        r.xgroup_create(STREAM_KEY, "test-group", id="0", mkstream=True)
        r.xreadgroup("test-group", "consumer-1", {STREAM_KEY: ">"}, count=10)

        consumer = _make_consumer(r)
        consumer._recover_pending()

        pending = r.xpending(STREAM_KEY, "test-group")
        assert pending["pending"] == 0


# ---------------------------------------------------------------------------
# AC-4  Idempotent ACK
# ---------------------------------------------------------------------------

class TestIdempotentAck:
    def test_double_ack_does_not_raise(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)

        consumer = _make_consumer(r)
        _drain(consumer)

        # Manually ACK already-acknowledged messages — should not raise
        all_ids = [entry[0] for entry in r.xrange(STREAM_KEY)]
        try:
            for sid in all_ids:
                r.xack(STREAM_KEY, "test-group", sid)
        except Exception as exc:
            pytest.fail(f"Double ACK raised unexpectedly: {exc}")

    def test_reprocessing_already_handled_message_is_safe(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)

        processed = []
        consumer = _make_consumer(r, handler=processed.append)
        _drain(consumer)
        initial_count = len(processed)

        # Re-run drain — no new messages should arrive
        _drain(consumer)
        assert len(processed) == initial_count


# ---------------------------------------------------------------------------
# AC-5  Dead-letter routing
# ---------------------------------------------------------------------------

class TestDeadLetterRouting:
    def test_persistently_failing_message_routed_to_dead_letter(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)

        def always_fail(_event: TranscriptEvent) -> None:
            raise RuntimeError("intentional failure")

        consumer = _make_consumer(r, handler=always_fail, max_retries=2)
        _drain(consumer)

        dead_letter_key = f"{STREAM_KEY}:dead-letter:test-group"
        dead = r.xrange(dead_letter_key)
        assert len(dead) == 1

    def test_dead_lettered_message_is_acknowledged(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)

        consumer = _make_consumer(
            r, handler=lambda _: (_ for _ in ()).throw(RuntimeError("boom")), max_retries=1
        )
        _drain(consumer)

        pending = r.xpending(STREAM_KEY, "test-group")
        assert pending["pending"] == 0

    def test_dead_letter_message_includes_provenance_metadata(self):
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=1)

        consumer = _make_consumer(
            r, handler=lambda _: (_ for _ in ()).throw(ValueError("bad")), max_retries=1
        )
        _drain(consumer)

        dead_letter_key = f"{STREAM_KEY}:dead-letter:test-group"
        entries = r.xrange(dead_letter_key)
        assert entries, "Dead-letter stream should not be empty"
        _, fields = entries[0]
        decoded = {k.decode(): v.decode() for k, v in fields.items()}
        assert "_original_stream_id" in decoded
        assert "_consumer_group" in decoded
        assert decoded["_consumer_group"] == "test-group"

    def test_consumer_continues_after_dead_letter(self):
        """A dead-lettered message must not stall processing of subsequent messages."""
        r = fakeredis.FakeRedis()
        _seed_stream(r, n=3)

        call_count = [0]
        fail_on_first = [True]

        def handler(_event: TranscriptEvent) -> None:
            if fail_on_first[0]:
                fail_on_first[0] = False
                raise RuntimeError("first message fails")
            call_count[0] += 1

        consumer = _make_consumer(r, handler=handler, max_retries=1)
        _drain(consumer)

        # First message dead-lettered; remaining 2 should have been handled
        assert call_count[0] == 2
