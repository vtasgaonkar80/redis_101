"""
transcript_consumer.py

Downstream consumer for real-time transcript events using Redis Streams
consumer groups. Each consumer instance manages its own offset independently,
allowing multiple consumers to process the same stream without impacting each other.

Event Contract (flat payload, system-wide schema):
    {
        "conversation_id": str,
        "turn_id":         str,
        "speaker":         str,   # "agent" | "customer"
        "text":            str,
        "timestamp":       str,   # ISO-8601
        "sequence":        int,
    }
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Callable, Optional

import redis

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

STREAM_KEY = "transcripts"
DEFAULT_BLOCK_MS = 5_000       # how long XREADGROUP blocks waiting for new msgs
DEFAULT_MAX_RETRIES = 3        # per-message processing retries before dead-letter
DEFAULT_CONSUMER_BATCH = 10    # messages fetched per XREADGROUP call


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TranscriptEvent:
    """Flat, immutable representation of a single transcript turn."""

    conversation_id: str
    turn_id: str
    speaker: str       # "agent" | "customer"
    text: str
    timestamp: str     # ISO-8601
    sequence: int

    # Redis stream ID that delivered this event (not part of the business schema)
    stream_id: str = ""

    @classmethod
    def from_redis_entry(cls, stream_id: str, fields: dict[bytes, bytes]) -> "TranscriptEvent":
        """Deserialise a raw Redis stream entry into a TranscriptEvent."""
        decoded = {k.decode(): v.decode() for k, v in fields.items()}
        return cls(
            conversation_id=decoded["conversation_id"],
            turn_id=decoded["turn_id"],
            speaker=decoded["speaker"],
            text=decoded["text"],
            timestamp=decoded["timestamp"],
            sequence=int(decoded["sequence"]),
            stream_id=stream_id,
        )


# ---------------------------------------------------------------------------
# Consumer
# ---------------------------------------------------------------------------

class TranscriptConsumer:
    """
    Subscribes to the `transcripts` Redis Stream via a consumer group.

    Each instance is identified by (group_name, consumer_name).  The group
    tracks which messages have been delivered and acknowledged; a crashed
    consumer can reclaim its pending messages on restart via XAUTOCLAIM /
    XPENDING without affecting other consumers in different groups.

    Usage
    -----
        def my_handler(event: TranscriptEvent) -> None:
            print(event.text)

        consumer = TranscriptConsumer(
            redis_client=redis.Redis(...),
            group_name="summariser-group",
            consumer_name="summariser-1",
            handler=my_handler,
        )
        consumer.run()
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        group_name: str,
        consumer_name: str,
        handler: Callable[[TranscriptEvent], None],
        *,
        stream_key: str = STREAM_KEY,
        block_ms: int = DEFAULT_BLOCK_MS,
        batch_size: int = DEFAULT_CONSUMER_BATCH,
        max_retries: int = DEFAULT_MAX_RETRIES,
        dead_letter_key: Optional[str] = None,
    ) -> None:
        self._redis = redis_client
        self._group = group_name
        self._consumer = consumer_name
        self._handler = handler
        self._stream = stream_key
        self._block_ms = block_ms
        self._batch_size = batch_size
        self._max_retries = max_retries
        self._dead_letter = dead_letter_key or f"{stream_key}:dead-letter:{group_name}"
        self._running = False

        self._ensure_group()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Block and process messages until stop() is called."""
        self._running = True
        logger.info(
            "Consumer %s/%s started on stream '%s'",
            self._group, self._consumer, self._stream,
        )

        # On startup, first drain any pending (unacknowledged) messages that
        # were delivered to *this* consumer before a previous crash.
        self._recover_pending()

        while self._running:
            messages = self._fetch_new(count=self._batch_size)
            if not messages:
                continue
            for stream_id, fields in messages:
                self._process_with_retry(stream_id, fields)

    def stop(self) -> None:
        """Signal the run-loop to exit after the current batch."""
        self._running = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_group(self) -> None:
        """Create the consumer group if it does not already exist."""
        try:
            self._redis.xgroup_create(
                self._stream,
                self._group,
                id="0",           # start from the very beginning of the stream
                mkstream=True,    # create the stream key if absent
            )
            logger.info("Created consumer group '%s'", self._group)
        except redis.exceptions.ResponseError as exc:
            if "BUSYGROUP" in str(exc):
                logger.debug("Consumer group '%s' already exists", self._group)
            else:
                raise

    def _fetch_new(self, count: int) -> list[tuple[str, dict]]:
        """
        Read the next `count` undelivered messages from the stream.
        Blocks for up to `_block_ms` ms if the stream is empty.
        Returns a flat list of (stream_id, fields) tuples.
        """
        response = self._redis.xreadgroup(
            groupname=self._group,
            consumername=self._consumer,
            streams={self._stream: ">"},   # ">" = only new, undelivered messages
            count=count,
            block=self._block_ms,
        )
        if not response:
            return []
        # response: [ [stream_key, [(id, {fields}), ...]], ... ]
        _, entries = response[0]
        return entries  # type: ignore[return-value]

    def _recover_pending(self) -> None:
        """
        Re-process messages that were delivered to this consumer but never
        acknowledged (e.g. due to a crash).  Uses XPENDING to discover them,
        then re-fetches via XRANGE for the actual payload.
        """
        pending = self._redis.xpending_range(
            self._stream,
            self._group,
            min="-",
            max="+",
            count=self._batch_size,
            consumername=self._consumer,
        )
        if not pending:
            return

        logger.info(
            "Recovering %d pending message(s) for %s/%s",
            len(pending), self._group, self._consumer,
        )
        for entry in pending:
            stream_id = entry["message_id"].decode()
            # Re-fetch the actual message content via XRANGE id id
            rows = self._redis.xrange(self._stream, min=stream_id, max=stream_id)
            if rows:
                _, fields = rows[0]
                self._process_with_retry(stream_id, fields)
            else:
                # Message was trimmed from the stream; acknowledge to clear pending
                logger.warning("Pending message %s no longer in stream; discarding", stream_id)
                self._redis.xack(self._stream, self._group, stream_id)

    def _process_with_retry(self, stream_id: str, fields: dict) -> None:
        """
        Attempt to deserialise and handle one message, retrying up to
        `max_retries` times on transient failures.  Permanently failed
        messages are forwarded to the dead-letter stream and acknowledged
        so they do not block the consumer.
        """
        for attempt in range(1, self._max_retries + 1):
            try:
                event = TranscriptEvent.from_redis_entry(stream_id, fields)
                self._handler(event)
                self._redis.xack(self._stream, self._group, stream_id)
                logger.debug("ACK %s (attempt %d)", stream_id, attempt)
                return
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Error processing %s (attempt %d/%d): %s",
                    stream_id, attempt, self._max_retries, exc,
                )
                if attempt < self._max_retries:
                    time.sleep(0.1 * attempt)   # simple linear back-off

        # All retries exhausted → dead-letter
        self._dead_letter_message(stream_id, fields)

    def _dead_letter_message(self, stream_id: str, fields: dict) -> None:
        """Forward a permanently failed message to the dead-letter stream and ACK it."""
        decoded = {k.decode() if isinstance(k, bytes) else k: v.decode() if isinstance(v, bytes) else v
                   for k, v in fields.items()}
        decoded["_original_stream_id"] = stream_id
        decoded["_consumer_group"] = self._group
        decoded["_consumer_name"] = self._consumer

        self._redis.xadd(self._dead_letter, decoded)
        self._redis.xack(self._stream, self._group, stream_id)
        logger.error(
            "Message %s moved to dead-letter stream '%s'", stream_id, self._dead_letter
        )
