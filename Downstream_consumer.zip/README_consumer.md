# Story 3 — Downstream Transcript Consumer

> **User story:** As a downstream consumer, I need to subscribe to real-time transcript events so that I can process conversation data as it becomes available without impacting other consumers.

---

## Overview

`TranscriptConsumer` wraps Redis Streams **consumer groups** so that every downstream service (summariser, sentiment analyser, QA auditor, …) can read the full `transcripts` stream at its own pace.  Each group maintains an independent read offset; acknowledging a message in one group has zero effect on any other.

This is Story 3 in the transcript pipeline:

```
[Ingestion Service (Story 1/2)]
        │  XADD
        ▼
  Redis Stream  "transcripts"
        │
        ├─ XREADGROUP ──► group: summariser-group   (this story)
        ├─ XREADGROUP ──► group: sentiment-group    (future)
        └─ XREADGROUP ──► group: qa-audit-group     (future)
```

---

## Files

| File | Purpose |
|------|---------|
| `transcript_consumer.py` | Production consumer implementation |
| `test_transcript_consumer.py` | Acceptance test suite (14 tests, 5 ACs) |

---

## Event Contract

Flat payload — aligns with the system-wide transcript schema written by the ingestion service:

| Field | Type | Description |
|-------|------|-------------|
| `conversation_id` | `str` | Identifies the CSR conversation |
| `turn_id` | `str` | Unique ID for this transcript turn |
| `speaker` | `str` | `"agent"` or `"customer"` |
| `text` | `str` | Transcript text for this turn |
| `timestamp` | `str` | ISO-8601 wall-clock time |
| `sequence` | `int` | Monotonic turn counter within conversation |

The `TranscriptEvent` dataclass enforces this contract at deserialisation time.

---

## Design Decisions

### Consumer Groups over plain XREAD
`XREADGROUP` gives each logical consumer its own server-side offset.  Two groups reading the same stream are completely independent — neither can "steal" or skip messages from the other.  This was the primary requirement from the ticket.

### `">"` vs explicit ID
Passing `">"` as the stream ID fetches only *new, undelivered* messages for this consumer.  On startup we first drain any *pending* (delivered but un-ACK'd) messages separately via `_recover_pending()` — the same crash-recovery pattern used in Story 2.

### Flat payload
Consumers receive a `TranscriptEvent` dataclass directly — no nested dicts, no raw bytes.  Downstream handlers stay simple:

```python
def summarise(event: TranscriptEvent) -> None:
    if event.speaker == "customer":
        pipeline.add(event.conversation_id, event.text)
```

### Dead-letter stream
After `max_retries` failures the message is written to  
`transcripts:dead-letter:<group_name>` with provenance metadata  
(`_original_stream_id`, `_consumer_group`, `_consumer_name`) and ACK'd.  
The consumer does **not** stall; subsequent messages are processed normally.

### Non-blocking in tests
`block_ms=0` is passed during tests so `XREADGROUP` returns immediately when the stream is empty, keeping the suite fast without any sleep/thread gymnastics.

---

## Acceptance Criteria → Tests

| AC | Description | Test class |
|----|-------------|------------|
| AC-1 | Handler called for every message; all ACK'd | `TestNormalConsumption` |
| AC-2 | Two groups on same stream each receive all messages | `TestIndependentOffsets` |
| AC-3 | Pending messages recovered and re-processed after crash | `TestCrashRecovery` |
| AC-4 | Double-ACK and reprocessing are safe (idempotent) | `TestIdempotentAck` |
| AC-5 | Persistently failing messages routed to dead-letter; consumer continues | `TestDeadLetterRouting` |

---

## Running the Tests

```bash
pip install redis fakeredis pytest
pytest test_transcript_consumer.py -v
```

Expected output: **14 passed**.

---

## Usage Example

```python
import redis
from transcript_consumer import TranscriptConsumer, TranscriptEvent

r = redis.Redis(host="localhost", port=6379, decode_responses=False)

def handle_event(event: TranscriptEvent) -> None:
    print(f"[{event.speaker}] {event.text}  (seq={event.sequence})")

consumer = TranscriptConsumer(
    redis_client=r,
    group_name="summariser-group",
    consumer_name="summariser-1",
    handler=handle_event,
)

consumer.run()   # blocks; call consumer.stop() from another thread to exit
```

---

## Consistency with Prior Stories

| Concern | Story 1/2 (Ingestion) | Story 3 (Consumer) |
|---------|----------------------|-------------------|
| Redis primitive | `XREAD BLOCK` / `XADD` | `XREADGROUP` / `XACK` |
| Offset storage | Redis key per service | Server-side per consumer group |
| Crash recovery | Re-read from stored pointer | Drain pending via `XPENDING` + `XRANGE` |
| Idempotency | Pointer only advances on success | ACK only on successful handler return |
| Dead-letter | N/A (ingestion retries) | `transcripts:dead-letter:<group>` stream |
| Test tooling | `fakeredis` | `fakeredis` |
